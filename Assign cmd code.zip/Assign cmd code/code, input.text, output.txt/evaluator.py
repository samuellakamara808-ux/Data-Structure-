import re

class Stack:
    def __init__(self):
        self.items = []

    def push(self, item):
        self.items.append(item)

    def pop(self):
        if not self.is_empty():
            return self.items.pop()
        raise IndexError("pop from empty stack")

    def peek(self):
        if not self.is_empty():
            return self.items[-1]
        return None

    def is_empty(self):
        return len(self.items) == 0

def tokenize(expression):
    expression = re.sub(r'(\d)(\()', r'\1*\2', expression)
    expression = re.sub(r'(\))(\d)', r'\1*\2', expression)
    expression = re.sub(r'(\))(\()', r'\1*\2', expression)
    
    tokens = []
    number_buffer = []
    for char in expression:
        if char in '+-*/()':
            if number_buffer:
                tokens.append(''.join(number_buffer))
                number_buffer = []
            tokens.append(char)
        elif char.isdigit() or char == '.':
            number_buffer.append(char)
        elif char == ' ':
            continue
        else:
            raise ValueError(f"Invalid character: {char}")
    if number_buffer:
        tokens.append(''.join(number_buffer))
    return tokens

def infix_to_postfix(tokens):
    precedence = {'+':1, '-':1, '*':2, '/':2}
    output = []
    stack = Stack()
    for token in tokens:
        if token.replace('.', '', 1).isdigit():
            output.append(token)
        elif token == '(':
            stack.push(token)
        elif token == ')':
            while not stack.is_empty() and stack.peek() != '(':
                output.append(stack.pop())
            stack.pop()
        else:
            while (not stack.is_empty() and 
                   stack.peek() != '(' and 
                   precedence.get(stack.peek(), 0) >= precedence.get(token, 0)):
                output.append(stack.pop())
            stack.push(token)
    while not stack.is_empty():
        output.append(stack.pop())
    return output

def evaluate_postfix(postfix):
    stack = Stack()
    for token in postfix:
        if token.replace('.', '', 1).isdigit():
            stack.push(float(token))
        else:
            b = stack.pop()
            a = stack.pop()
            if token == '+':
                stack.push(a + b)
            elif token == '-':
                stack.push(a - b)
            elif token == '*':
                stack.push(a * b)
            elif token == '/':
                if b == 0:
                    raise ZeroDivisionError("Division by zero")
                stack.push(a / b)
    return stack.pop()

def evaluate_expression(expression):
    try:
        tokens = tokenize(expression)
        postfix = infix_to_postfix(tokens)
        result = evaluate_postfix(postfix)
        return int(result) if isinstance(result, float) and result.is_integer() else result
    except:
        return "Error"

def main():
    with open('input.txt', 'r') as f:
        lines = [line.strip() for line in f.readlines()]
    
    output = []
    for line in lines:
        if not line:
            continue
        if all(c == '-' for c in line):
            output.append(line)
        else:
            result = evaluate_expression(line)
            output.append(str(result))
    
    with open('output.txt', 'w') as f:
        f.write('\n'.join(output))

if __name__ == '__main__':
    main()