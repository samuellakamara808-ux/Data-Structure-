 Mathematical Expression Evaluator

How to Run
1. Ensure Python 3.x is installed
2. Place input expressions in `input.txt`
3. Run `python evaluator.py`
4. Results will be written to `output.txt`

 Input Format
- One expression per line
- Separate different expressions with lines containing only hyphens (`------`)
- Supported operators: +, -, *, /, parentheses

 Assumptions
- Implicit multiplication between numbers and parentheses
- Division results in floating-point numbers
- Expressions must be well-formed with explicit operators

Limitations
- No support for exponents or unary operators
- Limited error handling for invalid expressions